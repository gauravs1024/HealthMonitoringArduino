package com.badalverse.app.services;

import org.springframework.stereotype.Service;

import com.badalverse.app.modal.User;
import com.badalverse.app.repository.Repo;

@Service
public class UserService {
    private final Repo repo;

    public UserService(Repo repo) {
        this.repo = repo;
    }
    
    public void saveData(User user){
        repo.save(user);
    }
}
