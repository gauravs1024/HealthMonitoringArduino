package com.badalverse.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConstantDataCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConstantDataCheckApplication.class, args);
	}

}
