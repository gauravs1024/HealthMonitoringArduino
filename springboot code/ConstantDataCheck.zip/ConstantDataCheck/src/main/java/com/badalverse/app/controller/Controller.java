package com.badalverse.app.controller;

// import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.badalverse.app.modal.User;
import com.badalverse.app.services.UserService;

@RestController
@RequestMapping("/api")
public class Controller {

    public final UserService serv;

    public Controller(UserService serv) {
        this.serv = serv;
    }
    
    @GetMapping("saveData")
    public String datasave(@RequestParam("data") int data) {
        User user = new User();
        user.setData(data);
        serv.saveData(user);
        return "Data saved";
    }
}
