package com.badalverse.app.repository;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.badalverse.app.modal.User;

@Repository
public class Repo {
    private final JdbcTemplate jdbcTemplate;

    public Repo(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void save(User user) {
        String query = "INSERT INTO users(data) VALUES (?)";
        jdbcTemplate.update(query, user.getData());
    }
}
